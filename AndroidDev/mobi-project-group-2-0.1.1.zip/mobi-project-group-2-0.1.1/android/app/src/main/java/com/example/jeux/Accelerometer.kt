package com.example.jeux

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import kotlin.math.abs
import kotlin.math.sqrt


class Accelerometer : ComponentActivity(), SensorEventListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_accelerometer)
        setupSensors()
    }

    override fun onResume() {
        super.onResume()
        mSensorManager!!.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        mSensorManager!!.unregisterListener(this)
        Log.v("SENSORS", "onPause SENSORS")
    }

    // Sensors
    private var mSensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    private fun setupSensors() {
        mSensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        // Use the accelerometer
        accelerometer = mSensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (accelerometer == null)
            finish() // Close app
    }

    private var recordAcceleration : Float = 0f
    override fun onSensorChanged(event: SensorEvent?) {
        val score: TextView = findViewById(R.id.Score)

        // Do some pythagorean theorem to get the total acceleration
        val A = sqrt((event!!.values[0]* event.values[0] + event.values[1]* event.values[1]).toDouble())
        val B = sqrt((event.values[2]* event.values[2] + event.values[1]* event.values[1]).toDouble())
        val C = sqrt(A*A + B*B)

        // If the current acceleration is larger than the previous record, set it as the new record and display it
        if(abs(C) > recordAcceleration) {
            recordAcceleration = abs(C).toFloat()
            score.text = "Highest acceleration is $recordAcceleration m/s squared"
        }
    }

    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {

    }

    fun finishGame(view: View) {
        finish()
    }

    fun saveHighScore(view: View) {
        val username: EditText = findViewById(R.id.username)

        FileManager(this).addHighscore(this, username.text.toString(), "Accelerometer", recordAcceleration)
    }
}
