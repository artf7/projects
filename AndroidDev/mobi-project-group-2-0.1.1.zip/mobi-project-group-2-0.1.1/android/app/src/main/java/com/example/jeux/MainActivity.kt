package com.example.jeux

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
    }

    fun wordleButton(view: View) {
        this.startActivity(Intent(this, Wordle::class.java))
    }

    fun rpsButton(view: View) {
        this.startActivity(Intent(this, RPS::class.java))
    }

    fun accelerometerButton(view: View) {
        this.startActivity(Intent(this, Accelerometer::class.java))
    }

    fun highscoreButton(view: View) {
        this.startActivity(Intent(this, HighscoreActivty::class.java))
    }
}