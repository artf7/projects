package com.example.jeux

import java.lang.Double.max

class Highscore {
    var games = HashMap<String, HashMap<String, Float>>()

    fun addHighScore(game: String, username: String, score: Float) {
        if(games[game] == null)
            games[game] = HashMap()
        if(games[game]?.get(username) != null) {
            if(games[game]?.get(username)!! > score)
                return
        }
        games[game]?.put(username, score)
    }
}