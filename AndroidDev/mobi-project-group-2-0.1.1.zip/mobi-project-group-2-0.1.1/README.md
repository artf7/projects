# Jeux
Jeux is a small-scale server based android game designed to make simple games competitive. Jeux will include a variety of simple and short games such as Sudoku and Tic Tac Toe. 

## Usage
### Server
1. Install node.js and git
2. Clone the repo
3. Enter the server directory
4. Install dependencies:
```bash
npm install
```
5. Start the server:
```bash
node index.js
```

## Contribution
1. Create a new branch for the proposed feature with ```git checkout -b branchname```.
2. Once the feature has been completed, merge any additional commits from main into the feature branch using ```git merge main```.
3. Once the feature branch has been brought up to date, open a pull request to merge it with main. 
