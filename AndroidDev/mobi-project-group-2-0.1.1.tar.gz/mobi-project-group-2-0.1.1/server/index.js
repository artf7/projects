/* Name: Jeux server
 * Author: Cale Stevens
 * Creation Date: 2023-10-04
 * Last Modified: 2023-10-04
 * Description: Server for Jeux android game
 */

import express from 'express';
import { createServer } from 'node:http';
import { Server } from 'socket.io';

const app = express();
const server = createServer(app);
const io = new Server(server);

// Runs when a client connects to the server
io.on('connection', (socket) => {
   console.log(socket.id + " has connected."); // Outputs the ID of the socket the client is connected through

   io.on("TEST", _ => {
      console.log("TEST");
   })
});



server.listen(3000, () => {
	console.log('server running at http://localhost:3000');
});
