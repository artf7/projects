package com.example.jeux

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.widget.addTextChangedListener
import com.example.jeux.databinding.ActivityMainBinding
import java.util.Locale
import kotlin.random.Random

class Wordle : ComponentActivity() {

    //provide access to each cell (simplify process)
    private lateinit var binding: ActivityMainBinding;
    //temporary list of words
    private var wordList = arrayOf("apple", "chair", "table", "music", "beach", "night", "dream", "piano", "smile")
    //generates random value from 0 to number of elements in the array
    private val random = Random.nextInt(0, wordList.size)

    private val WORD = wordList[random].uppercase(Locale.ROOT);

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //call function responsible for shifting focus to the next cell
        keepPassingFocus()
        //call function to check the line

        //validation of 1st line
        binding.edit15.addTextChangedListener{
            validateRow(binding.edit11,binding.edit12,binding.edit13,binding.edit14,binding.edit15)
        }
        //validation of 2nd line
        binding.edit25.addTextChangedListener{
            validateRow(binding.edit21,binding.edit22,binding.edit23,binding.edit24,binding.edit25)
        }
        //validation of 3rd line
        binding.edit35.addTextChangedListener{
            validateRow(binding.edit31,binding.edit32,binding.edit33,binding.edit34,binding.edit35)
        }
        //validation of 4th line
        binding.edit45.addTextChangedListener{
            validateRow(binding.edit41,binding.edit42,binding.edit43,binding.edit44,binding.edit45)
        }
        //validation of 5th line
        binding.edit55.addTextChangedListener{
            validateRow(binding.edit51,binding.edit52,binding.edit53,binding.edit54,binding.edit55)
        }
        //validation of 6th line
        binding.edit65.addTextChangedListener{
            validateRow(binding.edit61,binding.edit62,binding.edit63,binding.edit64,binding.edit65)
        }

    }

    //check the row after entering the last letter
    private fun validateRow(edt1: EditText, edt2: EditText, edt3: EditText, edt4: EditText, edt5: EditText) {
        val occurrences = mutableMapOf<Char, Int>()
        val edtArray = arrayOf(edt1, edt2, edt3, edt4, edt5)
        var input = ""

        for(i in 0..4) {
            input += edtArray[i].text.toString().uppercase(Locale.ROOT)
            occurrences[WORD[i]] = 0
        }

        // Function to check the occurrences of a correct letter and set the background color
        fun checkAndSetBackgroundColor(edt: EditText, correctLetter: Char) {
            // Update the occurrence for the letter
            occurrences.merge(correctLetter, 1, Int::plus)

            // Check if the correct letter has occurred more than once
            if (occurrences[correctLetter]!! > WORD.count { it == correctLetter})
                edt.setBackgroundColor(Color.parseColor("#808080")) // Grey color
            else
                edt.setBackgroundColor(Color.parseColor("#FFFF00")) // Yellow color for the first occurrence
        }

        // Loop through each character and see if it is in the correct position
        for(i in 0..4) {
            // If the character is in the correct position, turn it green
            if (WORD[i] == input[i]) {
                edtArray[i].setBackgroundColor(Color.parseColor("#77DD77"))
                occurrences.merge(WORD[i], 1, Int::plus)
            }
        }

        // Check for characters in the incorrect position
        for(i in 0..4) {
            // If the character is in the correct position, continue (since this was handled above)
            if(input[i] == WORD[i])
                continue
            // If the character is in the word (but not in the exact position), call checkAndSetBackgroundColor
            else if(WORD.indexOf(input[i], 0) != -1)
                checkAndSetBackgroundColor(edtArray[i], input[i])
            // Else, turn it grey
            else
                edtArray[i].setBackgroundColor(Color.parseColor("#808080"))

            edtArray[i].isEnabled = false
        }

        //winning combination
        if(input == WORD){
            Toast.makeText(this,"Congrats! You guess the word right!",Toast.LENGTH_SHORT).show();
            binding.txtWinLoose.visibility = View.VISIBLE
            binding.txtWinLoose.text ="Congrats! You guess the word right!"
            //make game inactive
            makeGameInactive()
            return
        }

        //loosing combination
        if(edt5.id == R.id.edit_65){
            Toast.makeText(this,"You didn't guess the word.",Toast.LENGTH_SHORT).show();
            binding.txtWinLoose.visibility = View.VISIBLE
            binding.txtWinLoose.text ="You didn't guess the word."
            //make game inactive
            makeGameInactive()
            return
        }

    }

    //after wining or loosing making the game is inactive
    private fun makeGameInactive() {
        //creating array of arrays that contain each cell from each column
        val arrayOfRows = arrayOf(
            //first row
            arrayOf(binding.edit11, binding.edit12, binding.edit13, binding.edit14, binding.edit15),
            //second row
            arrayOf(binding.edit21, binding.edit22, binding.edit23, binding.edit24, binding.edit25),
            //third row
            arrayOf(binding.edit31, binding.edit32, binding.edit33, binding.edit34, binding.edit35),
            //forth row
            arrayOf(binding.edit41, binding.edit42, binding.edit43, binding.edit44, binding.edit45),
            //fifth row
            arrayOf(binding.edit51, binding.edit52, binding.edit53, binding.edit54, binding.edit55),
            //sixth row
            arrayOf(binding.edit61, binding.edit62, binding.edit63, binding.edit64, binding.edit65)
        )

        //for loop go through rows
        for (row in arrayOfRows) {
            //nested for loop that go through all elements of arrays that contains in editTextArrays array
            for (editText in row) {
                //disable for input all cells
                editText.isEnabled = false
            }
        }
    }

    //shift focus to next ce:wqll after entering value in a cell
    private fun passFocusToNextEditText(edt1: EditText, edt2 : EditText){
        edt1.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(edt: Editable?) {
                // Check if the EditText has exactly one character entered.
                if(edt?.length == 1)
                {
                    // If one character is entered, move the focus to the next cell.
                    edt2.requestFocus()
                }

            }
        });
    }
    private fun keepPassingFocus() {
        //creating array of arrays that contain each cell from each column
        val arrayOfRows = arrayOf(
            //first row
            arrayOf(binding.edit11, binding.edit12, binding.edit13, binding.edit14, binding.edit15),
            //second row
            arrayOf(binding.edit21, binding.edit22, binding.edit23, binding.edit24, binding.edit25),
            //third row
            arrayOf(binding.edit31, binding.edit32, binding.edit33, binding.edit34, binding.edit35),
            //forth row
            arrayOf(binding.edit41, binding.edit42, binding.edit43, binding.edit44, binding.edit45),
            //fifth row
            arrayOf(binding.edit51, binding.edit52, binding.edit53, binding.edit54, binding.edit55),
            //sixth row
            arrayOf(binding.edit61, binding.edit62, binding.edit63, binding.edit64, binding.edit65)
        )
        // Loop through all rows
        for (i in arrayOfRows.indices) {
            // Loop through the EditText elements within each row (except the last one)
            for (j in 0 until arrayOfRows[i].size - 1) {
                // Pass focus from the current EditText to the next one in the same row
                passFocusToNextEditText(arrayOfRows[i][j], arrayOfRows[i][j + 1])
            }
            // Check if there is another row below (or  not the last row)
            if (i < arrayOfRows.size - 1) {
                // Pass focus from the last EditText in the current row to the first one in the next row
                passFocusToNextEditText(arrayOfRows[i].last(), arrayOfRows[i + 1].first())
            }
        }
    }

    fun finishGame(view: View) {
        finish()
    }
}
