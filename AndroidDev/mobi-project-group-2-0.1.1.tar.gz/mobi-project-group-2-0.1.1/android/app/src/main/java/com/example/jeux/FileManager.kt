package com.example.jeux

import android.content.Context
import com.google.gson.Gson
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter


class FileManager(context: Context) {
    private var filename: String = "highscores"

    companion object {
        var highscore: Highscore = Highscore()
    }

    init {
        val gson = Gson()

        val file = File(context.filesDir, filename)
//        file.delete() // Clears the file
        if(!file.exists()) {
            file.createNewFile()
            val fos = FileOutputStream(file)
            val osw = OutputStreamWriter(fos)
            osw.write(gson.toJson(highscore))
            osw.flush()
            osw.close()
            fos.close()
        }

        val fis = FileInputStream(file)
        val isr = InputStreamReader(fis)
        val br = BufferedReader(isr)

        val sb = StringBuilder()
        var line: String?
        while (br.readLine().also { line = it } != null) {
            sb.append(line)
        }

        highscore = gson.fromJson(sb.toString(), Highscore::class.java)

        br.close()
        isr.close()
        fis.close()
    }

    fun addHighscore(context: Context, username: String, game: String, score: Float) {
        highscore.addHighScore(game, username, score)

        val file = File(context.filesDir, filename)
        val fos = FileOutputStream(file, false)
        val osw = OutputStreamWriter(fos)
        osw.write(Gson().toJson(highscore))
        osw.flush()
        osw.close()
        fos.close()
    }
    fun getHighScore(): String {
        var output = ""
        for ((key, value) in highscore.games) {
            output += "Game: $key\n"
            for ((key, value) in value) {
                output += "Username: $key\nScore: $value\n"
            }
            output += "\n"
        }

        return output
    }
}
