package com.example.jeux

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AppCompatActivity
import com.example.jeux.R
import kotlin.random.Random

class RPS : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rps)

        val rockButton: Button = findViewById(R.id.Roc_But)
        val paperButon: Button = findViewById(R.id.Pap_But)
        val ScissorsButton: Button = findViewById(R.id.Sci_But)


        rockButton.setOnClickListener { playGame("rock") }
        paperButon.setOnClickListener { playGame("paper") }
        ScissorsButton.setOnClickListener { playGame("scissors") }
    }

    private fun playGame(playerChoice: String) {
        val choices = arrayOf("rock", "paper", "scissors")
        val computerChoice = choices[Random.nextInt(3)]
        val result = determineWinner(playerChoice, computerChoice)


        val choice: TextView = findViewById(R.id.results)

        choice.text = "Player chose $playerChoice\nComputer chose $computerChoice\n$result"
    }

    private fun determineWinner(playerChoice: String, computerChoice: String): String {
        if (playerChoice == computerChoice) {
            return "It's a tie!"
        } else if (
            (playerChoice == "rock" && computerChoice == "scissors") ||
            (playerChoice == "paper" && computerChoice == "rock") ||
            (playerChoice == "scissors" && computerChoice == "paper")
        ) {
            return "Player wins!"
        }
        return "Computer wins!"
    }

    fun finishGame(view: View) {
        finish()
    }
}